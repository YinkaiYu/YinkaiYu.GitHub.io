setjupyter宏包使用说明
--------------------------------

>  这个宏包是用来在 tex 里显示 jupyter notebook 样式的代码块的。
>  如果没有这样的需求，就不需要导入这个宏包。

 - 把 setjupyter.sty 文件复制到 tex 文件所在目录，在导言区使用`\usepackage{setjupyter}`指令调用 setjupyter 宏包。
 - 调用该宏包之后，直接把 jupyter notebook 导出的 tex 代码复制过来（一般只复制所需的片段）就可以正常编译。
 - 除此之外，我还定义了几个新的环境：
	 - `pynote`，`matnote`，`cppnote`，表示以 notebook 的代码输入的样式来显示代码块。
	 - `pynotein`，`matnotein`，`cppnotein`，表示以 notebook 的代码输入的样式来显示代码块，代码块前会有一个`[in]`标志，通常该环境和下面的输出环境搭配使用。
	 - `pynoteout`，`matnoteout`，`cppnoteout`，表示以 notebook 的代码输出的样式来显示代码块，代码块前会有一个`[out]`标志，通常该环境和上面的输入环境搭配使用。
	 
	 使用这些环境，就不需要借助 jupyter notebook 导出代码了。
	 下面我给几个例子，如果上面的描述不清楚，你把它复制到你的 tex 文件里编译一下就知道了：
	 
		 %% 放在导言区
		 \usepackage{setjupyter}
		 
		 %% 放在正文区
		 % 最常用的不带标志的代码快
		 \begin{pynote}
			 import numpy as np
			 a = [1, 2]
			 print( np.sum(a) )
		 \end{pynote}
		
		% 带输入标志的代码快
		 \begin{pynotein}
			 import numpy as np
			 a = [1, 2]
			 print( np.sum(a) )
		 \end{pynotein}

		% 带输出标志的代码快
		 \begin{pynoteout}
			 3
		 \end{pynoteout}

*——余荫铠 2022/4/19*



