def t_i_to_ip1(i, rider, p_i, t_i):
    t_ip1 = rider.m*x0**2 / ( p_i*t_i**2 + rider.m*x0**2/t_i - alpha*x0**2 - beta_[i]*x0*t_i )
    
    f_ip1 = alpha*x0/t_ip1 + beta_[i] + (m*x0/t_ip1)*(1/t_ip1 - 1/t_i)
    if ( (mu*m*9.8)**2 - f_ip1**2 ) * t_ip1**4 < ( m * x0**2 * kappa[i] )**2:
        t_ip1 = ( ( m * x0**2 * kappa[i] )**2/( (mu*m*9.8)**2 - f_ip1**2 ) )**0.25
return t_ip1