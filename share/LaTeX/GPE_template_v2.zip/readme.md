更新内容 2022/4/4
--------------------------------------------------------------

    修复了\question{}会让思考题的答案字体也被改变的问题。
    优化了“实验信息记录”部分的表格（仿自李小康）。
    添加了超链接标识的颜色（摘自余荫铠的电动力学作业模板）。
    添加了对代码环境的支持，尤其是python和matlab代码（改自莫梁虹的报告）。
    添加了对英文标题、摘要、关键词的快捷生成指令。
    修复了使用\begin{thebibliography}{99}方式生成参考文献时可能的错误（赖睿然反馈）。



一些新指令的用法简述
--------------------------------------------------------------

生成英文标题和摘要：

    在“参考文献”和“附录”之间插入指令\makeEngPage{}。
    当然，在此之前，需要在\def\papertitle{}定义中文标题时顺便也\def\papertitleEng{}定义一下英文标题，定义作者的英文名、合作者的英文名，指令都是在相应的原指令后面加“Eng”。要输入英文摘要内容和英文关键词内容，请使用\abstractEng{}指令和\keywordEng{}指令。在本版本的模板的article.tex模板中我给出了完整的例子。


制作实验仪器列表：

    使用instrmlist环境，比如
    \begin{instrmlist}
        手      & 短型          \\
        脑子    & 一个          \\
        某仪器  & 型号或数量    \\
    \end{instrmlist}


插入python/matlab代码块：

    使用pycode/matcode环境，比如
    \begin{pycode}
        from matplotlib import pyplot as plt
    \end{pycode}
    
    
在行内使用python/matlab代码：

    使用\pyinline{}或\matinline{}指令，比如\pyinline{from matplotlib import pyplot as plt}


导入python/matlab源代码文件：

    使用\pyfile{}或\matfile{}指令，比如\pyfile{code/fft.py}
  